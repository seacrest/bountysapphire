// import Web3 from 'web3'
// var web3 = new Web3()

export default function (string) {
  return web3.fromAscii(string, 32)
}
