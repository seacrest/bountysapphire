const webpack = require('webpack')

module.exports = {
  plugins: [
  ]
}
