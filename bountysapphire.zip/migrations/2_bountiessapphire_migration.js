var bountiesSapphire = artifacts.require('BountiesSapphire')

module.exports = function(deployer) {
  deployer.deploy(bountiesSapphire)
};

