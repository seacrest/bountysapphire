#! /bin/sh
ganache-cli --db .ganache -i 5780 -e 100 -a 10  -m "$HDWALLET_MNEMONIC"
