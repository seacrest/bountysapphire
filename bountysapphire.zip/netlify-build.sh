#! /bin/sh

truffle migrate --network rinkeby && \
npm run build
